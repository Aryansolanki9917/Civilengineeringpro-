import os
import json
from datetime import datetime
from flask import render_template, request, redirect, url_for, flash, jsonify, send_file, abort
from flask_login import login_user, logout_user, login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from app import app, db
from models import User, Subject, UploadedFile, Quiz, QuizQuestion, QuizAttempt, ForumPost, ForumReply
from utils import allowed_file, calculate_quiz_score

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        remember = bool(request.form.get('remember'))
        
        user = User.query.filter_by(username=username).first()
        
        if user and check_password_hash(user.password_hash, password):
            login_user(user, remember=remember)
            next_page = request.args.get('next')
            return redirect(next_page) if next_page else redirect(url_for('dashboard'))
        else:
            flash('Invalid username or password', 'error')
    
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        password = request.form['password']
        confirm_password = request.form['confirm_password']
        role = request.form['role']
        full_name = request.form['full_name']
        phone = request.form.get('phone', '')
        institution = request.form.get('institution', '')
        
        # Validation
        if password != confirm_password:
            flash('Passwords do not match', 'error')
            return render_template('register.html')
        
        if User.query.filter_by(username=username).first():
            flash('Username already exists', 'error')
            return render_template('register.html')
        
        if User.query.filter_by(email=email).first():
            flash('Email already exists', 'error')
            return render_template('register.html')
        
        # Create new user
        user = User(
            username=username,
            email=email,
            password_hash=generate_password_hash(password),
            role=role,
            full_name=full_name,
            phone=phone,
            institution=institution
        )
        
        db.session.add(user)
        db.session.commit()
        
        flash('Registration successful! Please log in.', 'success')
        return redirect(url_for('login'))
    
    return render_template('register.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash('You have been logged out.', 'info')
    return redirect(url_for('index'))

@app.route('/dashboard')
@login_required
def dashboard():
    stats = {
        'total_users': User.query.count(),
        'total_files': UploadedFile.query.count(),
        'total_quizzes': Quiz.query.count(),
        'total_posts': ForumPost.query.count(),
    }
    
    recent_files = UploadedFile.query.filter_by(is_public=True).order_by(UploadedFile.upload_date.desc()).limit(5).all()
    recent_posts = ForumPost.query.order_by(ForumPost.created_at.desc()).limit(5).all()
    
    return render_template('dashboard.html', stats=stats, recent_files=recent_files, recent_posts=recent_posts)

@app.route('/learning-hub')
@login_required
def learning_hub():
    subjects = Subject.query.all()
    if not subjects:
        # Create default subjects
        default_subjects = [
            {'name': 'Structural Engineering', 'description': 'Design and analysis of structures', 'icon': 'fas fa-building', 'color': '#3498db'},
            {'name': 'Geotechnical Engineering', 'description': 'Soil mechanics and foundation engineering', 'icon': 'fas fa-mountain', 'color': '#e74c3c'},
            {'name': 'Reinforced Concrete Construction', 'description': 'RCC design and construction', 'icon': 'fas fa-cube', 'color': '#9b59b6'},
            {'name': 'Strength of Materials', 'description': 'Material properties and behavior under loads', 'icon': 'fas fa-weight-hanging', 'color': '#f39c12'},
            {'name': 'Fluid Mechanics', 'description': 'Flow of fluids and hydraulics', 'icon': 'fas fa-tint', 'color': '#1abc9c'},
            {'name': 'Surveying', 'description': 'Land surveying and measurements', 'icon': 'fas fa-compass', 'color': '#34495e'},
            {'name': 'Transportation Engineering', 'description': 'Highway and traffic engineering', 'icon': 'fas fa-road', 'color': '#e67e22'},
            {'name': 'Environmental Engineering', 'description': 'Water and wastewater treatment', 'icon': 'fas fa-leaf', 'color': '#27ae60'},
        ]
        
        for subject_data in default_subjects:
            subject = Subject(**subject_data)
            db.session.add(subject)
        
        db.session.commit()
        subjects = Subject.query.all()
    
    return render_template('learning_hub.html', subjects=subjects)

@app.route('/quiz/<int:subject_id>')
@login_required
def quiz_list(subject_id):
    subject = Subject.query.get_or_404(subject_id)
    quizzes = Quiz.query.filter_by(subject_id=subject_id, is_active=True).all()
    return render_template('quiz.html', subject=subject, quizzes=quizzes)

@app.route('/take-quiz/<int:quiz_id>')
@login_required
def take_quiz(quiz_id):
    quiz = Quiz.query.get_or_404(quiz_id)
    questions = QuizQuestion.query.filter_by(quiz_id=quiz_id).all()
    
    # Create quiz attempt
    attempt = QuizAttempt(
        user_id=current_user.id,
        quiz_id=quiz_id,
        total_questions=len(questions)
    )
    db.session.add(attempt)
    db.session.commit()
    
    return render_template('take_quiz.html', quiz=quiz, questions=questions, attempt=attempt)

@app.route('/submit-quiz/<int:attempt_id>', methods=['POST'])
@login_required
def submit_quiz(attempt_id):
    attempt = QuizAttempt.query.get_or_404(attempt_id)
    
    # Check if this attempt belongs to current user
    if attempt.user_id != current_user.id:
        abort(403)
    
    # Get answers from form
    answers = {}
    questions = QuizQuestion.query.filter_by(quiz_id=attempt.quiz_id).all()
    
    for question in questions:
        answer_key = f'question_{question.id}'
        answers[str(question.id)] = request.form.get(answer_key, '')
    
    # Calculate score
    score, correct_answers = calculate_quiz_score(questions, answers)
    
    # Update attempt
    attempt.score = score
    attempt.answers = json.dumps(answers)
    attempt.completed_at = datetime.utcnow()
    
    db.session.commit()
    
    flash(f'Quiz completed! Your score: {score:.1f}% ({correct_answers}/{len(questions)})', 'success')
    return redirect(url_for('quiz_results', attempt_id=attempt.id))

@app.route('/quiz-results/<int:attempt_id>')
@login_required
def quiz_results(attempt_id):
    attempt = QuizAttempt.query.get_or_404(attempt_id)
    
    if attempt.user_id != current_user.id:
        abort(403)
    
    questions = QuizQuestion.query.filter_by(quiz_id=attempt.quiz_id).all()
    user_answers = json.loads(attempt.answers) if attempt.answers else {}
    
    return render_template('quiz_results.html', attempt=attempt, questions=questions, user_answers=user_answers)

@app.route('/calculators')
@login_required
def calculators():
    return render_template('calculators.html')

@app.route('/forum')
@login_required
def forum():
    page = request.args.get('page', 1, type=int)
    category = request.args.get('category', '')
    
    query = ForumPost.query
    if category:
        query = query.filter_by(category=category)
    
    posts = query.order_by(ForumPost.created_at.desc()).paginate(
        page=page, per_page=10, error_out=False
    )
    
    categories = ['General', 'Structural', 'Geotechnical', 'RCC', 'Surveying', 'Transportation', 'Environmental']
    
    return render_template('forum.html', posts=posts, categories=categories, current_category=category)

@app.route('/forum/new', methods=['GET', 'POST'])
@login_required
def new_post():
    if request.method == 'POST':
        title = request.form['title']
        content = request.form['content']
        category = request.form['category']
        
        post = ForumPost(
            title=title,
            content=content,
            author_id=current_user.id,
            category=category
        )
        
        db.session.add(post)
        db.session.commit()
        
        flash('Post created successfully!', 'success')
        return redirect(url_for('forum'))
    
    categories = ['General', 'Structural', 'Geotechnical', 'RCC', 'Surveying', 'Transportation', 'Environmental']
    return render_template('new_post.html', categories=categories)

@app.route('/forum/post/<int:post_id>')
@login_required
def view_post(post_id):
    post = ForumPost.query.get_or_404(post_id)
    post.views += 1
    db.session.commit()
    
    replies = ForumReply.query.filter_by(post_id=post_id).order_by(ForumReply.created_at.asc()).all()
    
    return render_template('view_post.html', post=post, replies=replies)

@app.route('/forum/post/<int:post_id>/reply', methods=['POST'])
@login_required
def reply_post(post_id):
    post = ForumPost.query.get_or_404(post_id)
    content = request.form['content']
    
    reply = ForumReply(
        post_id=post_id,
        author_id=current_user.id,
        content=content
    )
    
    db.session.add(reply)
    db.session.commit()
    
    flash('Reply posted successfully!', 'success')
    return redirect(url_for('view_post', post_id=post_id))

@app.route('/codes-library')
@login_required
def codes_library():
    return render_template('codes_library.html')

@app.route('/profile')
@login_required
def profile():
    user_attempts = QuizAttempt.query.filter_by(user_id=current_user.id).order_by(QuizAttempt.completed_at.desc()).limit(10).all()
    user_posts = ForumPost.query.filter_by(author_id=current_user.id).order_by(ForumPost.created_at.desc()).limit(5).all()
    
    return render_template('profile.html', attempts=user_attempts, posts=user_posts)

@app.route('/upload-file/<int:subject_id>', methods=['POST'])
@login_required
def upload_file(subject_id):
    subject = Subject.query.get_or_404(subject_id)
    
    if 'file' not in request.files:
        flash('No file selected', 'error')
        return redirect(url_for('learning_hub'))
    
    file = request.files['file']
    description = request.form.get('description', '')
    
    if file.filename == '':
        flash('No file selected', 'error')
        return redirect(url_for('learning_hub'))
    
    if file and allowed_file(file.filename):
        filename = secure_filename(file.filename)
        # Add timestamp to prevent conflicts
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S_')
        filename = timestamp + filename
        
        # Ensure upload directory exists
        upload_dir = os.path.join(app.config['UPLOAD_FOLDER'])
        os.makedirs(upload_dir, exist_ok=True)
        
        file_path = os.path.join(upload_dir, filename)
        file.save(file_path)
        
        # Save file info to database
        uploaded_file = UploadedFile(
            filename=filename,
            original_filename=file.filename,
            file_type=file.filename.rsplit('.', 1)[1].upper(),
            file_size=os.path.getsize(file_path),
            description=description,
            subject_id=subject_id,
            uploader_id=current_user.id
        )
        
        db.session.add(uploaded_file)
        db.session.commit()
        
        flash('File uploaded successfully!', 'success')
    else:
        flash('Invalid file type. Please upload PDF, DOC, DOCX, PPT, or PPTX files.', 'error')
    
    return redirect(url_for('learning_hub'))

@app.route('/download/<int:file_id>')
@login_required
def download_file(file_id):
    file_record = UploadedFile.query.get_or_404(file_id)
    file_path = os.path.join(app.config['UPLOAD_FOLDER'], file_record.filename)
    
    if os.path.exists(file_path):
        file_record.download_count += 1
        db.session.commit()
        return send_file(file_path, as_attachment=True, download_name=file_record.original_filename)
    else:
        flash('File not found', 'error')
        return redirect(url_for('learning_hub'))

@app.route('/api/convert-units', methods=['POST'])
@login_required
def convert_units():
    data = request.get_json()
    from_unit = data.get('from_unit')
    to_unit = data.get('to_unit')
    value = float(data.get('value', 0))
    unit_type = data.get('unit_type')
    
    # Unit conversion logic
    conversion_factors = {
        'length': {
            'm': 1.0,
            'cm': 0.01,
            'mm': 0.001,
            'km': 1000.0,
            'ft': 0.3048,
            'in': 0.0254
        },
        'area': {
            'm2': 1.0,
            'cm2': 0.0001,
            'mm2': 0.000001,
            'ft2': 0.092903,
            'in2': 0.00064516
        },
        'volume': {
            'm3': 1.0,
            'cm3': 0.000001,
            'l': 0.001,
            'ft3': 0.0283168,
            'in3': 0.0000163871
        },
        'force': {
            'N': 1.0,
            'kN': 1000.0,
            'kg': 9.81,
            'ton': 9810.0,
            'lb': 4.44822
        },
        'pressure': {
            'Pa': 1.0,
            'kPa': 1000.0,
            'MPa': 1000000.0,
            'psi': 6894.76,
            'bar': 100000.0
        }
    }
    
    if unit_type in conversion_factors:
        factors = conversion_factors[unit_type]
        if from_unit in factors and to_unit in factors:
            # Convert to base unit first, then to target unit
            base_value = value * factors[from_unit]
            result = base_value / factors[to_unit]
            return jsonify({'result': result, 'success': True})
    
    return jsonify({'error': 'Invalid conversion', 'success': False})

# Error handlers
@app.errorhandler(404)
def not_found_error(error):
    return render_template('404.html'), 404

@app.errorhandler(500)
def internal_error(error):
    db.session.rollback()
    return render_template('500.html'), 500
