# Civil Engineering Pro

## Overview

Civil Engineering Pro is a comprehensive web platform designed for civil engineering education and professional development. The application serves as a learning hub that connects students, engineers, teachers, and contractors through a unified platform offering educational resources, calculation tools, community forums, and quiz systems.

The platform provides:
- Educational resource management and sharing
- Interactive quizzes and assessments
- Engineering calculation tools
- Community forum for knowledge sharing
- User role management (Student, Engineer, Teacher, Contractor)
- Codes and standards library
- File upload and download capabilities

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
The application uses a traditional server-side rendered approach with Flask templates and Jinja2 templating engine. The frontend is built with:
- **Bootstrap 5.3.0** for responsive UI components and grid system
- **Font Awesome 6.4.0** for iconography
- **Google Fonts (Poppins)** for typography
- **Custom CSS** with CSS variables for theming and dark mode support
- **Vanilla JavaScript** for client-side interactions and animations

The template system follows a base template pattern with template inheritance, providing consistent navigation and layout across all pages.

### Backend Architecture
The backend is built on **Flask** (Python web framework) following a modular structure:
- **app.py**: Application factory and configuration
- **models.py**: SQLAlchemy ORM models for data layer
- **routes.py**: URL routing and request handling
- **utils.py**: Utility functions for file handling and calculations

The application uses Flask-Login for authentication and session management, with built-in user role management supporting different user types.

### Data Storage
The application uses **SQLAlchemy ORM** with a flexible database configuration:
- Default: SQLite for development (civil_engineering_app.db)
- Production: Configurable via DATABASE_URL environment variable
- Connection pooling with automatic reconnection (pool_recycle=300, pool_pre_ping=True)

### Database Schema
Key entities include:
- **User**: Authentication and profile management with role-based access
- **Subject**: Course/topic organization with customizable icons and colors
- **UploadedFile**: File management with metadata and access control
- **Quiz/QuizQuestion/QuizAttempt**: Assessment system with scoring
- **ForumPost/ForumReply**: Community discussion system

### Authentication & Authorization
- **Flask-Login** for session management
- **Werkzeug** for password hashing and security
- Role-based access control (Student, Engineer, Teacher, Contractor)
- File upload security with extension validation

### File Management
- Secure file uploads with size limits (16MB max)
- File type validation for educational content (PDF, DOC, PPT, images)
- Organized storage in static/uploads directory
- Download tracking and access control

## External Dependencies

### Core Framework Dependencies
- **Flask**: Web application framework
- **Flask-SQLAlchemy**: Database ORM integration
- **Flask-Login**: User authentication and session management
- **Werkzeug**: WSGI utilities and security helpers

### Frontend Dependencies (CDN)
- **Bootstrap 5.3.0**: UI framework and components
- **Font Awesome 6.4.0**: Icon library
- **Google Fonts**: Poppins font family

### Development Tools
- **ProxyFix**: WSGI middleware for proxy handling
- **Python logging**: Application logging and debugging

### File Storage
- Local file system storage in static/uploads
- Configurable upload directory via UPLOAD_FOLDER

The application is designed to be deployment-ready with environment variable configuration for database connections and security keys, making it suitable for both development and production environments.